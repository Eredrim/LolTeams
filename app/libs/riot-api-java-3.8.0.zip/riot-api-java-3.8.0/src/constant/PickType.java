package constant;

public enum PickType {
	BLIND_PICK,
	DRAFT_MODE,
	ALL_RANDOM,
	TOURNAMENT_DRAFT;
}
