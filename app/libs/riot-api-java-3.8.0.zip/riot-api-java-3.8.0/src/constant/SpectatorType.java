package constant;

public enum SpectatorType {
	NONE,
	LOBBYONLY,
	ALL;
}
