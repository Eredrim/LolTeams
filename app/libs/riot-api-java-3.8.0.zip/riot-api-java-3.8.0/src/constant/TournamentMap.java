package constant;

public enum TournamentMap {
	SUMMONERS_RIFT,
	TWISTED_TREELINE,
	CRYSTAL_SCAR,
	HOWLING_ABYSS;
}